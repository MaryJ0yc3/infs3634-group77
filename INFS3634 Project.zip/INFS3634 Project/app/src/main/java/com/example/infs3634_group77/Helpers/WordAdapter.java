package com.example.infs3634_group77.Helpers;

public class WordAdapter {

    //need to create cardview xml (not added yet)
}
