package com.example.infs3634_group77.Helpers;

public class CategoryAdapter {
    //delete if you don't want a recycler view for categories

    //high advised so that we can flex in report that it allows for more stages to be added later


    //need to create card view xml (not added yet)
}
