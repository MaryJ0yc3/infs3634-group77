package com.example.infs3634_group77.Helpers;

public interface WordService {
}
