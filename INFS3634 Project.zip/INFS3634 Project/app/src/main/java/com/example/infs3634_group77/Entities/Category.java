package com.example.infs3634_group77.Entities;

public class Category {

    //stores word objects. is an array list? or just a list?


}
